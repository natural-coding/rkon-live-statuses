<?php

declare(strict_types=1);

namespace App\Factories;

final class GoogleClientFactory
{
   static public function create() : \Google\Client
   {
      putenv('GOOGLE_APPLICATION_CREDENTIALS=' . realpath(__DIR__ . '/../../config/sensitive-data/service-account-credentials.json'));

      $client = new \Google_Client();
      $client->useApplicationDefaultCredentials();
      $client->addScope('https://www.googleapis.com/auth/spreadsheets');

      return $client;
   }
}