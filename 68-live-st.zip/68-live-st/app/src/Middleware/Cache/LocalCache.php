<?php
/**
 * Кэширование результата запроса (к таблицам google) в файловой системе
 *
 */
namespace Application\Cache;


class LocalCache
{
   // I will fill it later ;-)
/*   public function setKey($key, $data);
   public function getKey($p_key) : string;
   public function invalidateKey($p_key); // ban 
*/


}