<?php

declare(strict_types=1);

namespace App\Controllers\FrontendApi;

class StatusGetController
{
   public function __construct()
   {
      print __FUNCTION__ . ':::' .  __FILE__;
   }
}