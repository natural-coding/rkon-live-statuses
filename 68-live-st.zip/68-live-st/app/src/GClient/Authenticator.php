<?php
declare(strict_types=1);

namespace GClient;

class Authenticator
{
   static public function doAuthenticate(\Google\Client $p_client)
   {

   }
}