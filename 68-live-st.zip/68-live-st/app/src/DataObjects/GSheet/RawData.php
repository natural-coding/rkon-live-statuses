<?php
/*
// Autoload Composer.
require_once __DIR__ . '/vendor/autoload.php';

$client = getClient();

$service = new Google_Service_Sheets($client);

// The ID of the spreadsheet to retrieve data from.
$spreadsheetId = 'my-spreadsheet-id';  // TODO: Update placeholder value.

// The A1 notation of the values to retrieve.
$range = 'my-range';  // TODO: Update placeholder value.

$response = $service->spreadsheets_values->get($spreadsheetId, $range);

// TODO: Change code below to process the `response` object:
echo '<pre>', var_export($response, true), '</pre>', "\n";

*/
/**
 * @link https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets.values/get
 */

class RawData
{
   private $range
   public function __construct($p_range)
   {
      $this->range = $p_range;
   }
}