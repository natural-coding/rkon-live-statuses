<?php

declare(strict_types=1);

namespace Framework\Utils;

function dump_nice_header(string $p_headerString)
{
   printf('<p style="margin-top: 2rem">%s</p>', $p_headerString);
}

function dump_nice($p_variable, bool $p_isExit = true)
{
   print '<pre>';
   if (gettype($p_variable)==='array')
      print_r($p_variable);
   else
      var_dump($p_variable);
   print '</pre>';

   if ($p_isExit)
      die;
}

/**
 * l means "to live" :-)
 */
function dump_nice_l($p_variable)
{
   dump_nice($p_variable,false);
}

/**
 * Simple factory for GuzzleHtt\/Client
 */
class GuzzleHttpClientFactory
{
   static public function create() : \GuzzleHttp\Client
   {
      /**
       * Self signed certificate should work to debug HTTP requests! :-)
       * Parameter must be removed in release!!
       */
      return new \GuzzleHttp\Client(['verify'=>false]);
   }
}