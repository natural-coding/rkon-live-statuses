<?php
declare(strict_types=1);

namespace App\Config;

final class AppConst
{
   // Test sheet
   // https://docs.google.com/spreadsheets/d/1-DlnUNroZ56R32znkARn20Q7frnZ2rZFwEIJvZNZMOI/edit#gid=0
   public const TEST_SHEET_ID = '1-DlnUNroZ56R32znkARn20Q7frnZ2rZFwEIJvZNZMOI';

/*   // Copy of Статусы проблем Rubikon
   // https://docs.google.com/spreadsheets/d/1VtwjFP0bScA7mtIGUsVyPQ8cijLvbB1ERFwxZ_oLn7o/edit#gid=0
   public const SHEET_ID = '1VtwjFP0bScA7mtIGUsVyPQ8cijLvbB1ERFwxZ_oLn7o';

   public const OUR_SRV_SHEET_NAME = 'Наши сервисы';
   public const SRV_SHEET_NAME = 'Другие сервисы';

   public const NAMED_RANGE_DELIM = '_';*/
}