<?php

declare(strict_types=1);

require_once __DIR__ . '/../../vendor/autoload.php';

use function Framework\Utils\{dump_nice,dump_nice_l};

header('Content-Type: application/json');

print<<<EndMarker
[
  {
    "name": "Интеграция с Altegio",
    "is_our_flag": 1,
    "issues": [
      {
        "description": "Не работает установка у новых пользователей",
        "date_end": "22.06.2023",
        "status": "на проверке"
      },
      {
        "description": "Проблема в работе отправки сообщений",
        "status": "на модерации"
      },
      {
        "description": "Дублирование сделок при создании",
        "status": "в работе",
        "date_end": "Когда-нибудь ;-)"
      }
    ]
  },
  {
    "name": "WAZZUP",
    "is_our_flag": 0,
    "issues": [
      {
        "description": "Сбои в работе получения сообщений",
        "date_end": "Ближайшее время"
      }
    ]
  },
  {
    "name": "amoCRM",
    "is_our_flag": 0
  },
  {
    "name": "Sipuni",
    "is_our_flag": 0
  }
]
EndMarker;