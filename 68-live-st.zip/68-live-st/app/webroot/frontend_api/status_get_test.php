<?php

declare(strict_types=1);

require_once __DIR__ . '/../../vendor/autoload.php';

use function Framework\Utils\{dump_nice,dump_nice_l};

header('Content-Type: application/json');

$client = Framework\Utils\GuzzleHttpClientFactory::create();
$url = 'https://myrubikon.tech/pay/goods.php';

$response = $client->get($url);

// print $result->getBody();
// dump_nice([$result->getBody()]);
$IS_ASSOC_ARRAY = true;
// dump_nice(json_decode($response->getBody()->__toString(),$IS_ASSOC_ARRAY));
$servicesAsArray = json_decode($response->getBody()->__toString(),$IS_ASSOC_ARRAY);

$outputJsonAsArray["services"] = [];

// $servicesAsArray = array_slice($servicesAsArray, 0, 1);
// dump_nice($servicesAsArray);

usort($servicesAsArray, function($first,$second) {
         /**
          * Как должны быть упорядочены элементы в массиве
          */
         return ($first['name'] > $second['name']);
      }
   );

// dump_nice($servicesAsArray);

foreach($servicesAsArray as $it)
{
   array_push($outputJsonAsArray["services"], 
      ['name' => $it['name'],'is_our_flag' => 1]
   );
}

// dump_nice_l($outputJsonAsArray);
$outputServicesAsJson = json_encode($outputJsonAsArray);

if (is_null($outputServicesAsJson))
   $outputServicesAsJson = '[]';

print $outputServicesAsJson;