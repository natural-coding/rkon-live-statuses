<?php

declare(strict_types=1);

require_once __DIR__ . '/../../vendor/autoload.php';

use function Framework\Utils\{dump_nice,dump_nice_l};

$client = App\Factories\GoogleClientFactory::create();
$service = new Google_Service_Sheets($client);

// $spreadsheetId = '1qvr2i7x4B0xG_yzwfqF7fAfjJIKQofCmOashey8JovM';


// The A1 notation of the values to retrieve.
// $range = 'A1:E3';  // TODO: Update placeholder value.
$range = 'Наши сервисы';  // TODO: Update placeholder value.
// $range = 'Другие сервисы';  // TODO: Update placeholder value.


///////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////
// $response = $service->spreadsheets_values->get(
//    App\Config\AppConst::TEST_SHEET_ID, 
//    $range
// );

// dump_nice($response['values']);
///////////////////////////////////////////////////////////////////////////
// RESPONSE


$range = 'Наши сервисы!A1';

$requestBody = new Google_Service_Sheets_ValueRange();
$requestBody->setValues([[73,73,73,73]]);

$queryParams = ['valueInputOption' => 'RAW', 'insertDataOption' => 'INSERT_ROWS'];

$response = $service->spreadsheets_values->append(
   App\Config\AppConst::TEST_SHEET_ID,
   $range, 
   $requestBody,
   $queryParams
);

// TODO: Change code below to process the `response` object:
echo '<pre>', var_export($response, true), '</pre>', "\n";