<?php

declare(strict_types=1);

require_once __DIR__ . '/../vendor/autoload.php';

// require_once __DIR__ . '/../config/config.php';

use App\Factories\GoogleClientFactory;

$client = GoogleClientFactory::create();
die;

print $a;
// die;

print \Config\AppConst::SHEET_ID;
print 'Hi! :-)';

die;

use function Framework\Utils\{dump_nice,dump_nice_l};

putenv('GOOGLE_APPLICATION_CREDENTIALS=' . realpath(__DIR__ . '/../config/sensitive-data/service-account-credentials.json'));

$client = new Google_Client();
$client->useApplicationDefaultCredentials();
$client->addScope('https://www.googleapis.com/auth/spreadsheets');
$service = new Google_Service_Sheets($client);

$spreadsheetId = '1qvr2i7x4B0xG_yzwfqF7fAfjJIKQofCmOashey8JovM';

// The A1 notation of the values to retrieve.
// $range = 'A1:E3';  // TODO: Update placeholder value.
// $range = 'Наши сервисы';  // TODO: Update placeholder value.
$range = 'Другие сервисы';  // TODO: Update placeholder value.

$response = $service->spreadsheets_values->get($spreadsheetId, $range);
dump_nice($response['values']);

// TODO: Change code below to process the `response` object:
echo '<pre>', var_export($response, true), '</pre>', "\n";

die;

$client = Framework\Utils\GuzzleHttpClientFactory::create();

// $url = 'https://ya.ru';
$url = 'https://myrubikon.tech/pay/goods.php';

$response = $client->get($url);

print $response->getBody();
// dump_nice([$result->getBody()]);
// dump_nice(json_decode($response->getBody()));

// dump_nice($response->getHeaders());