<?php

declare(strict_types=1);

require_once __DIR__ . '/../../vendor/autoload.php';

use function Framework\Utils\{dump_nice,dump_nice_l};

$client = App\Factories\GoogleClientFactory::create();
$service = new Google_Service_Sheets($client);

// ///////////////////////////////////////////////////////////////////////////
// // https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/get
// ///////////////////////////////////////////////////////////////////////////
// $response = $service->spreadsheets->get(App\Config\AppConst::TEST_SHEET_ID);

// echo '<pre>', var_export($response, true), '</pre>', "\n";

// die;

///////////////////////////////////////////////////////////////////////////
// https://developers.google.com/sheets/api/reference/rest/v4/spreadsheets/get
///////////////////////////////////////////////////////////////////////////
$response = $service->spreadsheets->get(App\Config\AppConst::TEST_SHEET_ID);

echo '<pre>', var_export($response, true), '</pre>', "\n";

die;
