<?php

declare(strict_types=1);

require_once __DIR__ . '/../../vendor/autoload.php';

use function Framework\Utils\{dump_nice,dump_nice_l};

$proto = ($_SERVER['HTTP_HOST'] === 'localhost' ? 'http://' : 'https://');

$request_uri = '/frontend_api/status_get_test.php';

$url = sprintf('%s%s%s', $proto, $_SERVER['HTTP_HOST'], $request_uri);

$client = Framework\Utils\GuzzleHttpClientFactory::create();

$response = $client->get($url);


$responseJson = json_decode($response->getBody()->__toString(),);
$responseJsonAsEncodedString = json_encode($responseJson, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);


dump_nice_l($responseJsonAsEncodedString);