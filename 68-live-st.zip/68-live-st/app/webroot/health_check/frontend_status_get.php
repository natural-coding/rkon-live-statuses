<?php

declare(strict_types=1);

require_once __DIR__ . '/../../vendor/autoload.php';

use function Framework\Utils\{dump_nice,dump_nice_l};

$proto = ($_SERVER['HTTP_HOST'] === 'localhost' ? 'http://' : 'https://');

$request_uri = '/frontend_api/status_get.php';

$url = sprintf('%s%s%s', $proto, $_SERVER['HTTP_HOST'], $request_uri);

$client = Framework\Utils\GuzzleHttpClientFactory::create();

$response = $client->get($url);
dump_nice_l($response->getBody()->__toString());