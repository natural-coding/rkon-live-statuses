<?php
phpinfo();
file_put_contents('file','hhh!');